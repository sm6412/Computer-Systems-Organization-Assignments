unsigned int f5(unsigned  int x)
{
  int a=x;
  int ret;
  int w;
  int q;
  int b;
    
  switch(x){
    case 1:
      ret=a;
      ret=ret<<2;
      w= ret;
      break;
    case 2:
      ret=a;
      b=1+ret;
      a=b;
      w=ret;
      break;
    case 3:
      w=check(x);
      break;
    case 4:
      w=count(x);
      break;
    
    case 5:
      w=7;
      break;
    
    default:
      b=a;
      ret=b;
      ret=ret+ret;
      ret=ret+b;
      w=ret;
    }
    
    ret=w;
    return ret;
        
 }
    
int check(unsigned int x){
  int y=1;
  int ret;
  int w;
    
  while(x!=0){
    w=y;
    ret=x;
    ret=ret+w;
    y=ret;
    x=x-1;
  }
      
  ret=y;
  return ret;
}
    
int count(unsigned int x){
  int y=0;
  int ret;
  int w;
    
  while(x!=0){
    ret=x;
    ret=ret&1;
    w=ret;
    y=y<<1;
    x=x>>1;
  }
    
  ret=y;
  return ret;
  
}

   
  

