int f3(unsigned int i)
{
  int x=i;
  int y =0;
  int ret;
  
  while(x!=0){
    ret=x;
    ret=ret&1;
    if(ret==0){
        x=x>>1;
    }
    else{
        y=y+1;
        x=x>>1;  
      }
    }
    
    
    ret=y;
    ret=-ret;
    return ret;
}
