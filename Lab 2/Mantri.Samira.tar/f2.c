long f2(int x)
{
  long y=x;
  long w=17;
  long z=y;
  long ret= z;
  ret=ret<<3;
  ret=ret-z;
  y=ret;
  int q=0;
    
  ret=q;
    
  while(ret<y){
    ret=q;
    w=w+ret;
    q=q+1;
    ret=q;
  }
    ret=w;
    return ret;

   
}