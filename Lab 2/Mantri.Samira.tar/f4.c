char f4(unsigned int i)
{
  int y=i;
  int ret;
  if(y<=15 && y>10){
    ret=y;
    ret=ret+96;
  }
  else if(y>15){
    ret=65;
  }
  else{
    ret=y;
    ret=ret+64;
  }
  
  return ret;
}
