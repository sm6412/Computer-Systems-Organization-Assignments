int f1(int x)
{
    int y=x;
    int ret;
    //correct
    if(y<=15){
       ret=y;
       ret=ret>>1;
       ret=ret+7;
    }
    // correct
    else{
       ret=y;
       int z;
       z=ret*8;
       ret=y;
       ret=ret<<2;
       z=z+ret;
       ret=x;
       ret=ret+ret;
       ret=ret+z;
    }
    
    return ret;
}